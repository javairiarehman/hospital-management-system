

   <html>
   <body style= "background: pink">
   

		<style>
.button {
background-color: blue;
color: white;





}
</style>








   


<h1><center>HOSPITAL LOG IN </center></h1>
<center><br> <font size="+1">CNIC NUMBER:</font></center>

<center><input type="text" name="cnic"></center>
<center><br> <font size="+1">PASSWORD:</font></center>

<center><input type="text" name="password"></center>


<br>
<input type="hidden" name="form_submitted" value="1" />
<center><td width= "80%"><label    for="login"><button class="button">LOGIN</button></label> </td></center>
</body>
</html>