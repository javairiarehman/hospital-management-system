<html>
	<head>
	<title>HJ HOSPITAL  </title>
	<style type ="text/css">
		.redfont {
	          color:red;
              font-size:40px;			  
		}
	</style>	
	</head>
		<body >
		<style>
.button {
background-color: blue;
color: white;
padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;




}
</style>
		<table width="100%" >
		  <tr >
		     <td width= "40%" ><img src="images/LOGO.jpg" width="130px" height="70px"></td>
			 <center><td width="30%"><h1 style="color:green">HJ HOSPITAL </h1> </td></center>
			 <td width="30%"></td>
 <td width= "80%"><label    for="login"><button class="button"><a href="connection.php" style="color:white ; text-decoration:none"><strong>LOGIN</strong></a></button></label> </td>
        
		  </tr>
		</table>
		<table width="100%" height="8%" style="background-color:red ;color:white" border="2px">
		  <tr>	
		     <td width="20px"style="font-size20px;text-align:center"><a href="display.php" style="color:white ; text-decoration:none"><strong> Home</strong></a></td>
		     <td width="20px"style="font-size20px;text-align:center"><a href="aboutus.php" style="color:white ; text-decoration:none"><strong> About us</strong></a></td>
		     <td width="20px"style="font-size20px;text-align:center"><a href="doctor_sp.php" style="color:white ; text-decoration:none"><strong>Doctor specialization</strong></a></td>
			 <td width="20px"style="font-size20px;text-align:center"><a href="pharmacy.php" style="color:white ; text-decoration:none"><strong> Pharmacy</strong></a></td>
			 <td width="20px"style="font-size20px;text-align:center"><a href="contact_us.php" style="color:white ; text-decoration:none"><strong>Contact info</strong></a></td>
          </tr>		
		</table>	
		<img width="100%" height ="30%" src="images/contact.jpg" >
		<table width="60%" style="float:left">
		<tr>
		    <td>
				<h2 class="text-gray-dimgray font-weight-600"><em><strong>CONTACT INFORMATION</strong></em></h2></td>
                        <td>    <h2 class="text-gray-dimgray font-weight-600">ADDRESS:</h2>
						<h4 >Hayttabad Peshawar 
                            </h4>
							</td>
							<td><h2 class="text-gray-dimgray font-weight-600">NAMES OF OWNER</h2>
							
							<h4>HIFZA MAJEED 
							<br>
							 JAVAIRIA REHMAN</h4></td>
							<td><h2 class="text-gray-dimgray font-weight-600">EMAIL:</h2>
						<h4>hj@gmail.com </h4></td>
						<br>
						<td><h2 class="text-gray-dimgray font-weight-600">CALL US:</h2>
							<h4>
							 03454234890
							<br>
							 03443523531</h4></td>
			
		</tr>
		</table>
		
		<br><br>
		

		
		</body>




</html>
