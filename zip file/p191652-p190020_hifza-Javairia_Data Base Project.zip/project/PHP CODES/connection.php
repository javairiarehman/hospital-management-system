<html>
	<head>
	<title>HJ HOSPITAL  </title>
	<style type ="text/css">
		.redfont {
	          color:red;
              font-size:40px;			  
		}
	</style>	
	</head>
		<body background="images/connection.jpg">
		<style>
.button {
background-color: blue;
color: white;
padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;




}
</style>
		<table width="100%" >
		  <tr >
			 <td width="40%"></td>
			 <center><td width="60%"><h1 style="color:green">HJ HOSPITAL </h1> </td></center>
			 <td width= "20%" ><img src="images/LOGO.jpg" width="130px" height="70px"></td>
			 

       
		  </tr>
		</table>
		<table width="100%" height="25%" style="background-color:orange ;color:white" border="2px">
		  <tr>	
		   <br>
		<br>
		<br>
		<br>
		<br><br>
		<br>
		<br>
		<br>
		<br>
		     <td width="40px"style="font-size40px;text-align:center"><a href="login1.php" style="color:white ; text-decoration:none"><strong> patient</strong></a></td>
		     <td width="40px"style="font-size40px;text-align:center"><a href="login2.php" style="color:white ; text-decoration:none"><strong> Doctor</strong></a></td>
		     <td width="40px"style="font-size40px;text-align:center"><a href="login3.php" style="color:white ; text-decoration:none"><strong>Admin</strong></a></td>
			 
			 
          </tr>		
		</table>	
		
		<br><br>
		
<br>
<input type="hidden" name="log" value="1" /></center>
<center><td width= "80%"><label    for="log"><button class="button"><a href="display.php" style="color:white ; text-decoration:none">BACK</a></button></label> </td></center>

		
		</body>




</html>
