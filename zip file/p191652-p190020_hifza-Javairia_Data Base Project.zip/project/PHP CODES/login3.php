<html>
	<head>
	<title>HJ HOSPITAL  </title>
	<style type ="text/css">
		.redfont {
	          color:red;
              font-size:40px;			  
		}
	</style>	
	</head>
		<body background="images/login3.jpg">
		<style>
.button {
background-color: blue;
color: white;
padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;




}
</style>
		<table width="100%" >
		  <tr >
			 <td width="40%"></td>
			 <center><td width="60%"><h1 style="color:green">HJ HOSPITAL </h1> </td></center>
			 <td width= "20%" ><img src="images/LOGO.jpg" width="130px" height="70px"></td>
			 

       
		  </tr>
		</table>
		<table width="100%" height="25%" style="background-color:orange ;color:white" border="2px">
		  <tr>	
		   <br>
		<br>
		<br>
		<br>
		<br><br>
		<br>
		<br>
		<br>
		<br>
		     <td width="40px"style="font-size40px;text-align:center"><a href="patient_view.php" style="color:white ; text-decoration:none"><strong>view patient</strong></a></td>
		     <td width="40px"style="font-size40px;text-align:center"><a href="edit_doc.php" style="color:white ; text-decoration:none"><strong>Edit Doctor</strong></a></td>
		     <td width="40px"style="font-size40px;text-align:center"><a href="app_view.php" style="color:white ; text-decoration:none"><strong>View appoinments</strong></a></td>
			 
			 
          </tr>		
		</table>	
		
		<br><br>
		<br>
<input type="hidden" name="log" value="1" /></center>
<center><td width= "80%"><label    for="log"><button class="button"><a href="connection.php" style="color:white ; text-decoration:none">BACK</a></button></label> </td></center>

		
		</body>




</html>
